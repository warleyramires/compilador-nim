boolean verdadeiro() {
  return true;
}
